#ifndef __TIMER_H__
#define __TIMER_H__

void timer_init();

extern BOOL f1ms;

#endif
