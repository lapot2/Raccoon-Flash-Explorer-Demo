#ifndef __USB_REQ_CLASS_H__
#define __USB_REQ_CLASS_H__

void usb_req_class();

#endif
