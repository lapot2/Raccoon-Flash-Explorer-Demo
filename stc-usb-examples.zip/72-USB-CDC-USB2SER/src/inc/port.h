#ifndef __PORT_H__
#define __PORT_H__

sbit    DOWNLOAD    =   P3^2;
sbit    LED_POWER   =   P6^7;
sbit    SVCC_E      =   P4^0;

#endif
