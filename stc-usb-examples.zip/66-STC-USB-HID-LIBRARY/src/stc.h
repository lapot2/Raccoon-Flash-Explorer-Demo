#ifndef __STC_H__
#define __STC_H__

#include <intrins.h>
#include <stdio.h>
#include <string.h>

#include "stc8h.h"
#include "config.h"

#endif
