#ifndef __USB_REQ_VENDOR_H__
#define __USB_REQ_VENDOR_H__

void usb_req_vendor();

#endif
