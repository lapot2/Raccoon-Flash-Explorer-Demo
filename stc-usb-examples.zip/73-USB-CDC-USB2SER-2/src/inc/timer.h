#ifndef __TIMER_H__
#define __TIMER_H__

void timer_init();

extern BOOL f1ms;
extern BOOL f10ms;

#endif
